<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
  /**
   * Run the migrations.
   */
  public function up(): void
  {
    Schema::create('campaign_recipient', function (Blueprint $table) {
      $table->id();
      $table->foreignId('campaign_id')->constrained()->cascadeOnDelete();
      $table->foreignId('recipient_id')->constrained()->cascadeOnDelete();
      $table->timestamp('sent_at')->nullable();
      $table->timestamp('opened_at')->nullable();
      $table->timestamp('clicked_at')->nullable();
      $table->timestamp('failed_at')->nullable();
      $table->text('error_message')->nullable();
      $table->timestamps();

      $table->unique(['campaign_id', 'recipient_id']);
    });
  }

  /**
   * Reverse the migrations.
   */
  public function down(): void
  {
    Schema::dropIfExists('campaign_recipient');
  }
};
